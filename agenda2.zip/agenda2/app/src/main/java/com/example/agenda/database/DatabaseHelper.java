package com.example.agenda.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.agenda.models.Odontologo;
import com.example.agenda.models.Paciente;
import com.example.agenda.models.Cita;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Nombre y versión de la base de datos
    private static final String DATABASE_NAME = "consultorio.db";
    private static final int DATABASE_VERSION = 1;

    // Tabla Odontólogo
    private static final String TABLE_ODONTOLOGO = "odontologo";
    private static final String COL_ODO_ID = "id";
    private static final String COL_ODO_NOMBRE = "nombre_completo";
    private static final String COL_ODO_EDAD = "edad";
    private static final String COL_ODO_FOTO = "foto_uri";
    private static final String COL_ODO_HORA_INICIO = "hora_inicio";
    private static final String COL_ODO_HORA_FIN = "hora_fin";

    // Tabla Pacientes
    private static final String TABLE_PACIENTES = "pacientes";
    private static final String COL_PAC_ID = "id";
    private static final String COL_PAC_NOMBRE = "nombre";
    private static final String COL_PAC_APELLIDOS = "apellidos";
    private static final String COL_PAC_GENERO = "genero";
    private static final String COL_PAC_FECHA_NAC = "fecha_nacimiento";

    // Tabla Citas
    private static final String TABLE_CITAS = "citas";
    private static final String COL_CIT_ID = "id";
    private static final String COL_CIT_PACIENTE_ID = "paciente_id";
    private static final String COL_CIT_FECHA = "fecha";
    private static final String COL_CIT_HORA_INICIO = "hora_inicio";
    private static final String COL_CIT_DURACION = "duracion_minutos";
    private static final String COL_CIT_TIPO_PROC = "tipo_procedimiento";
    private static final String COL_CIT_ESTADO = "estado";
    private static final String COL_CIT_MONTO = "monto_cobrado";
    private static final String COL_CIT_DESCRIPCION = "descripcion_tratamiento";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crear tabla Odontólogo
        String createOdontologo = "CREATE TABLE " + TABLE_ODONTOLOGO + " (" +
                COL_ODO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ODO_NOMBRE + " TEXT, " +
                COL_ODO_EDAD + " INTEGER, " +
                COL_ODO_FOTO + " TEXT, " +
                COL_ODO_HORA_INICIO + " TEXT, " +
                COL_ODO_HORA_FIN + " TEXT)";
        db.execSQL(createOdontologo);

        // Crear tabla Pacientes
        String createPacientes = "CREATE TABLE " + TABLE_PACIENTES + " (" +
                COL_PAC_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_PAC_NOMBRE + " TEXT NOT NULL, " +
                COL_PAC_APELLIDOS + " TEXT NOT NULL, " +
                COL_PAC_GENERO + " TEXT, " +
                COL_PAC_FECHA_NAC + " TEXT)";
        db.execSQL(createPacientes);

        // Crear tabla Citas
        String createCitas = "CREATE TABLE " + TABLE_CITAS + " (" +
                COL_CIT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CIT_PACIENTE_ID + " INTEGER NOT NULL, " +
                COL_CIT_FECHA + " TEXT NOT NULL, " +
                COL_CIT_HORA_INICIO + " TEXT NOT NULL, " +
                COL_CIT_DURACION + " INTEGER NOT NULL, " +
                COL_CIT_TIPO_PROC + " TEXT, " +
                COL_CIT_ESTADO + " TEXT DEFAULT 'pendiente', " +
                COL_CIT_MONTO + " REAL DEFAULT 0, " +
                COL_CIT_DESCRIPCION + " TEXT, " +
                "FOREIGN KEY(" + COL_CIT_PACIENTE_ID + ") REFERENCES " +
                TABLE_PACIENTES + "(" + COL_PAC_ID + "))";
        db.execSQL(createCitas);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CITAS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PACIENTES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ODONTOLOGO);
        onCreate(db);
    }
    // ============== MÉTODOS PARA ODONTÓLOGO ==============

    public long insertarOdontologo(Odontologo odontologo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_ODO_NOMBRE, odontologo.getNombreCompleto());
        values.put(COL_ODO_EDAD, odontologo.getEdad());
        values.put(COL_ODO_FOTO, odontologo.getFotoUri());
        values.put(COL_ODO_HORA_INICIO, odontologo.getHoraInicio());
        values.put(COL_ODO_HORA_FIN, odontologo.getHoraFin());

        long id = db.insert(TABLE_ODONTOLOGO, null, values);
        db.close();
        return id;
    }

    public boolean actualizarOdontologo(Odontologo odontologo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_ODO_NOMBRE, odontologo.getNombreCompleto());
        values.put(COL_ODO_EDAD, odontologo.getEdad());
        values.put(COL_ODO_FOTO, odontologo.getFotoUri());
        values.put(COL_ODO_HORA_INICIO, odontologo.getHoraInicio());
        values.put(COL_ODO_HORA_FIN, odontologo.getHoraFin());

        int rows = db.update(TABLE_ODONTOLOGO, values,
                COL_ODO_ID + " = ?",
                new String[]{String.valueOf(odontologo.getId())});
        db.close();
        return rows > 0;
    }

    public Odontologo obtenerOdontologo() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ODONTOLOGO, null, null, null,
                null, null, null, "1");

        Odontologo odontologo = null;
        if (cursor.moveToFirst()) {
            odontologo = new Odontologo(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_ODO_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ODO_NOMBRE)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_ODO_EDAD)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ODO_FOTO)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ODO_HORA_INICIO)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ODO_HORA_FIN))
            );
        }
        cursor.close();
        db.close();
        return odontologo;
    }
    // ============== MÉTODOS PARA PACIENTES ==============

    public long insertarPaciente(Paciente paciente) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_PAC_NOMBRE, paciente.getNombre());
        values.put(COL_PAC_APELLIDOS, paciente.getApellidos());
        values.put(COL_PAC_GENERO, paciente.getGenero());
        values.put(COL_PAC_FECHA_NAC, paciente.getFechaNacimiento());

        long id = db.insert(TABLE_PACIENTES, null, values);
        db.close();
        return id;
    }

    public boolean actualizarPaciente(Paciente paciente) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_PAC_NOMBRE, paciente.getNombre());
        values.put(COL_PAC_APELLIDOS, paciente.getApellidos());
        values.put(COL_PAC_GENERO, paciente.getGenero());
        values.put(COL_PAC_FECHA_NAC, paciente.getFechaNacimiento());

        int rows = db.update(TABLE_PACIENTES, values,
                COL_PAC_ID + " = ?",
                new String[]{String.valueOf(paciente.getId())});
        db.close();
        return rows > 0;
    }

    public boolean eliminarPaciente(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_PACIENTES, COL_PAC_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public Paciente obtenerPacientePorId(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PACIENTES, null,
                COL_PAC_ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null);

        Paciente paciente = null;
        if (cursor.moveToFirst()) {
            paciente = new Paciente(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_PAC_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_NOMBRE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_APELLIDOS)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_GENERO)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_FECHA_NAC))
            );
        }
        cursor.close();
        db.close();
        return paciente;
    }

    public List<Paciente> obtenerTodosPacientes() {
        List<Paciente> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PACIENTES, null, null, null,
                null, null, COL_PAC_APELLIDOS + " ASC");

        if (cursor.moveToFirst()) {
            do {
                Paciente paciente = new Paciente(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_PAC_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_NOMBRE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_APELLIDOS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_GENERO)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_FECHA_NAC))
                );
                lista.add(paciente);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return lista;
    }

    public List<Paciente> buscarPacientes(String busqueda) {
        List<Paciente> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_PACIENTES +
                " WHERE " + COL_PAC_NOMBRE + " LIKE ? OR " +
                COL_PAC_APELLIDOS + " LIKE ? ORDER BY " +
                COL_PAC_APELLIDOS + " ASC";

        String parametro = "%" + busqueda + "%";
        Cursor cursor = db.rawQuery(query, new String[]{parametro, parametro});

        if (cursor.moveToFirst()) {
            do {
                Paciente paciente = new Paciente(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_PAC_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_NOMBRE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_APELLIDOS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_GENERO)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PAC_FECHA_NAC))
                );
                lista.add(paciente);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return lista;
    }
    // ============== MÉTODOS PARA CITAS ==============

    public long insertarCita(Cita cita) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_CIT_PACIENTE_ID, cita.getPacienteId());
        values.put(COL_CIT_FECHA, cita.getFecha());
        values.put(COL_CIT_HORA_INICIO, cita.getHoraInicio());
        values.put(COL_CIT_DURACION, cita.getDuracionMinutos());
        values.put(COL_CIT_TIPO_PROC, cita.getTipoProcedimiento());
        values.put(COL_CIT_ESTADO, cita.getEstado());
        values.put(COL_CIT_MONTO, cita.getMontoCobrado());
        values.put(COL_CIT_DESCRIPCION, cita.getDescripcionTratamiento());

        long id = db.insert(TABLE_CITAS, null, values);
        db.close();
        return id;
    }

    public boolean actualizarCita(Cita cita) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_CIT_PACIENTE_ID, cita.getPacienteId());
        values.put(COL_CIT_FECHA, cita.getFecha());
        values.put(COL_CIT_HORA_INICIO, cita.getHoraInicio());
        values.put(COL_CIT_DURACION, cita.getDuracionMinutos());
        values.put(COL_CIT_TIPO_PROC, cita.getTipoProcedimiento());
        values.put(COL_CIT_ESTADO, cita.getEstado());
        values.put(COL_CIT_MONTO, cita.getMontoCobrado());
        values.put(COL_CIT_DESCRIPCION, cita.getDescripcionTratamiento());

        int rows = db.update(TABLE_CITAS, values,
                COL_CIT_ID + " = ?",
                new String[]{String.valueOf(cita.getId())});
        db.close();
        return rows > 0;
    }

    public boolean eliminarCita(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_CITAS, COL_CIT_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public Cita obtenerCitaPorId(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT c.*, p." + COL_PAC_NOMBRE + " || ' ' || p." +
                COL_PAC_APELLIDOS + " as nombre_paciente FROM " +
                TABLE_CITAS + " c INNER JOIN " + TABLE_PACIENTES +
                " p ON c." + COL_CIT_PACIENTE_ID + " = p." +
                COL_PAC_ID + " WHERE c." + COL_CIT_ID + " = ?";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(id)});

        Cita cita = null;
        if (cursor.moveToFirst()) {
            cita = new Cita(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_ID)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_PACIENTE_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow("nombre_paciente")),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_FECHA)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_HORA_INICIO)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_DURACION)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_TIPO_PROC)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_ESTADO)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COL_CIT_MONTO)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_DESCRIPCION))
            );
        }
        cursor.close();
        db.close();
        return cita;
    }

    public List<Cita> obtenerCitasPorFecha(String fecha) {
        List<Cita> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT c.*, p." + COL_PAC_NOMBRE + " || ' ' || p." +
                COL_PAC_APELLIDOS + " as nombre_paciente FROM " +
                TABLE_CITAS + " c INNER JOIN " + TABLE_PACIENTES +
                " p ON c." + COL_CIT_PACIENTE_ID + " = p." +
                COL_PAC_ID + " WHERE c." + COL_CIT_FECHA + " = ? " +
                "ORDER BY c." + COL_CIT_HORA_INICIO + " ASC";

        Cursor cursor = db.rawQuery(query, new String[]{fecha});

        if (cursor.moveToFirst()) {
            do {
                Cita cita = new Cita(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_PACIENTE_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow("nombre_paciente")),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_FECHA)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_HORA_INICIO)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_DURACION)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_TIPO_PROC)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_ESTADO)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_CIT_MONTO)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_DESCRIPCION))
                );
                lista.add(cita);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return lista;
    }


    public double obtenerIngresosPorFecha(String fecha) {
        SQLiteDatabase db = this.getReadableDatabase();
        double total = 0.0;

        String query = "SELECT SUM(" + COL_CIT_MONTO + ") as total FROM " +
                TABLE_CITAS + " WHERE " + COL_CIT_FECHA + " = ? AND " +
                COL_CIT_ESTADO + " = 'asistio'";

        Cursor cursor = db.rawQuery(query, new String[]{fecha});
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(cursor.getColumnIndexOrThrow("total"));
        }
        cursor.close();
        db.close();
        return total;
    }

    public double obtenerIngresosPorRango(String fechaInicio, String fechaFin) {
        SQLiteDatabase db = this.getReadableDatabase();
        double total = 0.0;

        String query = "SELECT SUM(" + COL_CIT_MONTO + ") as total FROM " +
                TABLE_CITAS + " WHERE " + COL_CIT_FECHA + " BETWEEN ? AND ? AND " +
                COL_CIT_ESTADO + " = 'asistio'";

        Cursor cursor = db.rawQuery(query, new String[]{fechaInicio, fechaFin});
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(cursor.getColumnIndexOrThrow("total"));
        }
        cursor.close();
        db.close();
        return total;
    }

    // ============== OBTENER HISTORIAL COMPLETO DEL PACIENTE ==============

    public List<Cita> obtenerHistorialPaciente(int pacienteId) {
        List<Cita> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT c.*, p." + COL_PAC_NOMBRE + " || ' ' || p." +
                COL_PAC_APELLIDOS + " as nombre_paciente FROM " +
                TABLE_CITAS + " c INNER JOIN " + TABLE_PACIENTES +
                " p ON c." + COL_CIT_PACIENTE_ID + " = p." +
                COL_PAC_ID + " WHERE c." + COL_CIT_PACIENTE_ID + " = ? " +
                "ORDER BY c." + COL_CIT_FECHA + " DESC, c." +
                COL_CIT_HORA_INICIO + " DESC";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(pacienteId)});

        if (cursor.moveToFirst()) {
            do {
                Cita cita = new Cita(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_PACIENTE_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow("nombre_paciente")),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_FECHA)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_HORA_INICIO)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_DURACION)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_TIPO_PROC)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_ESTADO)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_CIT_MONTO)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_DESCRIPCION))
                );
                lista.add(cita);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return lista;
    }
    // ============== MÉTODO PARA OBTENER CITAS POR MES ==============

    public List<Cita> obtenerCitasPorMes(int anio, int mes) {
        List<Cita> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String mesStr = String.format("%04d-%02d", anio, mes);

        String query = "SELECT c.*, p." + COL_PAC_NOMBRE + " || ' ' || p." +
                COL_PAC_APELLIDOS + " as nombre_paciente FROM " +
                TABLE_CITAS + " c INNER JOIN " + TABLE_PACIENTES +
                " p ON c." + COL_CIT_PACIENTE_ID + " = p." +
                COL_PAC_ID + " WHERE c." + COL_CIT_FECHA + " LIKE ? " +
                "ORDER BY c." + COL_CIT_FECHA + " ASC, c." +
                COL_CIT_HORA_INICIO + " ASC";

        Cursor cursor = db.rawQuery(query, new String[]{mesStr + "%"});

        if (cursor.moveToFirst()) {
            do {
                Cita cita = new Cita(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_PACIENTE_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow("nombre_paciente")),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_FECHA)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_HORA_INICIO)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_CIT_DURACION)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_TIPO_PROC)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_ESTADO)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_CIT_MONTO)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_CIT_DESCRIPCION))
                );
                lista.add(cita);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return lista;
    }
}