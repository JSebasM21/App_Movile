package com.example.agenda.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agenda.R;
import com.example.agenda.adapters.HistorialAdapter;
import com.example.agenda.database.DatabaseHelper;
import com.example.agenda.models.Cita;
import com.example.agenda.models.Paciente;

import java.util.List;
import java.util.Locale;

public class HistorialPacienteActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView rvHistorial;
    private HistorialAdapter adapter;
    private TextView tvNombrePaciente, tvEdadPaciente, tvTotalCitas, tvTotalGastado, tvUltimaVisita;
    private TextView tvCitasPendientes, tvCitasTratadas;
    private int pacienteId;
    private Paciente paciente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial_paciente);

        // Configurar toolbar con botón de retroceso
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Historial del Paciente");
        }

        db = new DatabaseHelper(this);

        // Obtener ID del paciente
        pacienteId = getIntent().getIntExtra("paciente_id", -1);

        if (pacienteId == -1) {
            Toast.makeText(this, "Error al cargar paciente", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Inicializar vistas
        tvNombrePaciente = findViewById(R.id.tvNombrePacienteHistorial);
        tvEdadPaciente = findViewById(R.id.tvEdadPacienteHistorial);
        tvTotalCitas = findViewById(R.id.tvTotalCitas);
        tvTotalGastado = findViewById(R.id.tvTotalGastado);
        tvUltimaVisita = findViewById(R.id.tvUltimaVisita);
        tvCitasPendientes = findViewById(R.id.tvCitasPendientes);
        tvCitasTratadas = findViewById(R.id.tvCitasTratadas);
        rvHistorial = findViewById(R.id.rvHistorial);

        rvHistorial.setLayoutManager(new LinearLayoutManager(this));

        cargarDatos();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatos();
    }

    private void cargarDatos() {
        // Cargar datos del paciente
        paciente = db.obtenerPacientePorId(pacienteId);

        if (paciente == null) {
            Toast.makeText(this, "Paciente no encontrado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvNombrePaciente.setText(paciente.getNombreCompleto());
        tvEdadPaciente.setText(paciente.calcularEdad() + " años - " + paciente.getGenero());

        // Cargar historial de citas
        List<Cita> historial = db.obtenerHistorialPaciente(pacienteId);

        // Calcular estadísticas
        int totalCitas = historial.size();
        int citasCompletadas = 0;
        int citasPendientes = 0;
        int citasTratadas = 0;
        double totalGastado = 0.0;
        String ultimaVisita = "Nunca";

        for (Cita cita : historial) {
            if (cita.getEstado().equals("asistio")) {
                citasCompletadas++;
                totalGastado += cita.getMontoCobrado();
                if (ultimaVisita.equals("Nunca")) {
                    ultimaVisita = cita.getFecha();
                }

                // Verificar si está cerrada (tratada)
                if (cita.estaCerrada()) {
                    citasTratadas++;
                }
            } else if (cita.getEstado().equals("pendiente")) {
                citasPendientes++;
            }
        }

        tvTotalCitas.setText(String.format(Locale.getDefault(),
                "📊 Total de citas: %d (Completadas: %d)", totalCitas, citasCompletadas));
        tvTotalGastado.setText(String.format(Locale.getDefault(),
                "💰 Total gastado: $%.2f", totalGastado));
        tvUltimaVisita.setText("📅 Última visita: " + ultimaVisita);
        tvCitasPendientes.setText(String.format(Locale.getDefault(),
                "⏳ Citas pendientes: %d", citasPendientes));
        tvCitasTratadas.setText(String.format(Locale.getDefault(),
                "✅ Citas tratadas: %d", citasTratadas));

        // Configurar adaptador con click listener
        adapter = new HistorialAdapter(historial, this::abrirDetalleCita);
        rvHistorial.setAdapter(adapter);
    }

    private void abrirDetalleCita(Cita cita) {
        Intent intent = new Intent(HistorialPacienteActivity.this, DetalleCitaActivity.class);
        intent.putExtra("cita_id", cita.getId());
        startActivity(intent);
    }
}