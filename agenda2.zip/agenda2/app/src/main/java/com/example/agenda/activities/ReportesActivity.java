package com.example.agenda.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.agenda.R;
import com.example.agenda.database.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ReportesActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private TextView tvIngresosDia, tvIngresosSemana, tvIngresosMes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reportes);

        // Configurar toolbar con botón de retroceso
        Toolbar toolbar = findViewById(R.id.toolbarReportes);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Reportes de Ingresos");
        }

        db = new DatabaseHelper(this);

        tvIngresosDia = findViewById(R.id.tvIngresosDia);
        tvIngresosSemana = findViewById(R.id.tvIngresosSemana);
        tvIngresosMes = findViewById(R.id.tvIngresosMes);

        cargarReportes();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void cargarReportes() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Calendar cal = Calendar.getInstance();

        // Ingresos del día
        String hoy = sdf.format(cal.getTime());
        double ingresosDia = db.obtenerIngresosPorFecha(hoy);
        tvIngresosDia.setText(String.format(Locale.getDefault(),
                "Ingresos de hoy: $%.2f", ingresosDia));

        // Ingresos de la semana
        cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        String inicioSemana = sdf.format(cal.getTime());
        cal.add(Calendar.DAY_OF_WEEK, 6);
        String finSemana = sdf.format(cal.getTime());
        double ingresosSemana = db.obtenerIngresosPorRango(inicioSemana, finSemana);
        tvIngresosSemana.setText(String.format(Locale.getDefault(),
                "Ingresos esta semana: $%.2f", ingresosSemana));

        // Ingresos del mes
        cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        String inicioMes = sdf.format(cal.getTime());
        cal.add(Calendar.MONTH, 1);
        cal.add(Calendar.DAY_OF_MONTH, -1);
        String finMes = sdf.format(cal.getTime());
        double ingresosMes = db.obtenerIngresosPorRango(inicioMes, finMes);
        tvIngresosMes.setText(String.format(Locale.getDefault(),
                "Ingresos este mes: $%.2f", ingresosMes));
    }
}