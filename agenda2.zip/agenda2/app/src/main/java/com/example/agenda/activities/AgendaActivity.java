package com.example.agenda.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agenda.R;
import com.example.agenda.adapters.CitaAdapter;
import com.example.agenda.database.DatabaseHelper;
import com.example.agenda.models.Cita;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AgendaActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private CalendarView calendarView;
    private RecyclerView rvCitas;
    private TextView tvFechaSeleccionada, tvTotalIngresos;
    private FloatingActionButton fabNuevaCita;
    private CitaAdapter adapter;
    private String fechaSeleccionada;
    private Map<String, Integer> diasConCitas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda);

        // Configurar toolbar con botón de retroceso
        Toolbar toolbar = findViewById(R.id.toolbarAgenda);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Agenda de Citas");
        }

        db = new DatabaseHelper(this);

        calendarView = findViewById(R.id.calendarView);
        rvCitas = findViewById(R.id.rvCitas);
        tvFechaSeleccionada = findViewById(R.id.tvFechaSeleccionada);
        tvTotalIngresos = findViewById(R.id.tvTotalIngresos);
        fabNuevaCita = findViewById(R.id.fabNuevaCita);

        rvCitas.setLayoutManager(new LinearLayoutManager(this));

        // Obtener fecha actual en español
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", new Locale("es", "ES"));
        fechaSeleccionada = sdf.format(cal.getTime());

        tvFechaSeleccionada.setText(formatearFecha(fechaSeleccionada));

        // Cargar días con citas para marcarlos
        cargarDiasConCitas();

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            fechaSeleccionada = String.format(Locale.getDefault(),
                    "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            tvFechaSeleccionada.setText(formatearFecha(fechaSeleccionada));
            cargarCitasDelDia();
        });

        fabNuevaCita.setOnClickListener(v -> {
            Intent intent = new Intent(AgendaActivity.this, NuevaCitaActivity.class);
            intent.putExtra("fecha", fechaSeleccionada);
            startActivity(intent);
        });

        cargarCitasDelDia();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDiasConCitas();
        cargarCitasDelDia();
    }

    private void cargarDiasConCitas() {
        diasConCitas = new HashMap<>();

        // Obtener todas las citas del mes actual
        Calendar cal = Calendar.getInstance();
        int mesActual = cal.get(Calendar.MONTH) + 1;
        int anioActual = cal.get(Calendar.YEAR);

        List<Cita> todasCitas = db.obtenerCitasPorMes(anioActual, mesActual);

        for (Cita cita : todasCitas) {
            String fecha = cita.getFecha();
            diasConCitas.put(fecha, diasConCitas.getOrDefault(fecha, 0) + 1);
        }

        // Nota: CalendarView de Android no permite personalizar colores por día de forma nativa
        // Para una implementación avanzada, necesitarías una librería como Material Calendar View
        // Por ahora, la información está disponible en el Map diasConCitas
    }

    private void cargarCitasDelDia() {
        List<Cita> citas = db.obtenerCitasPorFecha(fechaSeleccionada);
        adapter = new CitaAdapter(citas, this::abrirDetalleCita);
        rvCitas.setAdapter(adapter);

        double total = db.obtenerIngresosPorFecha(fechaSeleccionada);

        // Mostrar información adicional sobre el día
        int numCitas = citas.size();
        String infoCitas = "";
        if (numCitas == 0) {
            infoCitas = " - Sin citas";
        } else if (numCitas == 1) {
            infoCitas = " - 1 cita";
        } else {
            infoCitas = " - " + numCitas + " citas";
        }

        tvTotalIngresos.setText(String.format(Locale.getDefault(),
                "💰 Ingresos: $%.2f%s", total, infoCitas));
    }

    private void abrirDetalleCita(Cita cita) {
        Intent intent = new Intent(AgendaActivity.this, DetalleCitaActivity.class);
        intent.putExtra("cita_id", cita.getId());
        startActivity(intent);
    }

    private String formatearFecha(String fecha) {
        try {
            SimpleDateFormat sdfInput = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat sdfOutput = new SimpleDateFormat("EEEE, dd 'de' MMMM 'de' yyyy",
                    new Locale("es", "ES"));
            return sdfOutput.format(sdfInput.parse(fecha));
        } catch (Exception e) {
            return fecha;
        }
    }
}