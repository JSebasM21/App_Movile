package com.example.agenda.models;

public class Cita {
    private int id;
    private int pacienteId;
    private String pacienteNombre; // Para mostrar sin consultar
    private String fecha;
    private String horaInicio;
    private int duracionMinutos;
    private String tipoProcedimiento;
    private String estado; // "pendiente", "asistio", "cancelo", "no_asistio"
    private double montoCobrado;
    private String descripcionTratamiento;

    // Constructor vacío
    public Cita() {
        this.estado = "pendiente";
        this.montoCobrado = 0.0;
    }

    // Constructor completo
    public Cita(int id, int pacienteId, String pacienteNombre, String fecha,
                String horaInicio, int duracionMinutos, String tipoProcedimiento,
                String estado, double montoCobrado, String descripcionTratamiento) {
        this.id = id;
        this.pacienteId = pacienteId;
        this.pacienteNombre = pacienteNombre;
        this.fecha = fecha;
        this.horaInicio = horaInicio;
        this.duracionMinutos = duracionMinutos;
        this.tipoProcedimiento = tipoProcedimiento;
        this.estado = estado;
        this.montoCobrado = montoCobrado;
        this.descripcionTratamiento = descripcionTratamiento;
    }

    // Método para calcular hora fin
    public String getHoraFin() {
        try {
            String[] partes = horaInicio.split(":");
            int hora = Integer.parseInt(partes[0]);
            int minutos = Integer.parseInt(partes[1]);

            minutos += duracionMinutos;
            hora += minutos / 60;
            minutos = minutos % 60;

            return String.format("%02d:%02d", hora, minutos);
        } catch (Exception e) {
            return horaInicio;
        }
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPacienteId() { return pacienteId; }
    public void setPacienteId(int pacienteId) { this.pacienteId = pacienteId; }

    public String getPacienteNombre() { return pacienteNombre; }
    public void setPacienteNombre(String pacienteNombre) {
        this.pacienteNombre = pacienteNombre;
    }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public String getHoraInicio() { return horaInicio; }
    public void setHoraInicio(String horaInicio) { this.horaInicio = horaInicio; }

    public int getDuracionMinutos() { return duracionMinutos; }
    public void setDuracionMinutos(int duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public String getTipoProcedimiento() { return tipoProcedimiento; }
    public void setTipoProcedimiento(String tipoProcedimiento) {
        this.tipoProcedimiento = tipoProcedimiento;
    }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public double getMontoCobrado() { return montoCobrado; }
    public void setMontoCobrado(double montoCobrado) {
        this.montoCobrado = montoCobrado;
    }

    public String getDescripcionTratamiento() { return descripcionTratamiento; }
    public void setDescripcionTratamiento(String descripcionTratamiento) {
        this.descripcionTratamiento = descripcionTratamiento;
    }

    public boolean estaCerrada() {
        return montoCobrado > 0 && descripcionTratamiento != null &&
                !descripcionTratamiento.isEmpty();
    }
}