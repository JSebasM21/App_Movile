package com.example.agenda.activities;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agenda.R;
import com.example.agenda.adapters.PacienteAdapter;
import com.example.agenda.database.DatabaseHelper;
import com.example.agenda.models.Paciente;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;
import java.util.List;

public class PacientesActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView rvPacientes;
    private PacienteAdapter adapter;
    private EditText etBuscar;
    private FloatingActionButton fabAgregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pacientes);

        // Configurar toolbar con botón de retroceso
        Toolbar toolbar = findViewById(R.id.toolbarPacientes);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Gestión de Pacientes");
        }

        db = new DatabaseHelper(this);

        etBuscar = findViewById(R.id.etBuscar);
        rvPacientes = findViewById(R.id.rvPacientes);
        fabAgregar = findViewById(R.id.fabAgregar);

        rvPacientes.setLayoutManager(new LinearLayoutManager(this));

        fabAgregar.setOnClickListener(v -> mostrarDialogoAgregar());

        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                buscarPacientes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        cargarPacientes();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void cargarPacientes() {
        List<Paciente> pacientes = db.obtenerTodosPacientes();
        adapter = new PacienteAdapter(
                pacientes,
                this::mostrarDialogoEditar,
                this::eliminarPaciente,
                this::abrirHistorial
        );
        rvPacientes.setAdapter(adapter);
    }

    private void buscarPacientes(String busqueda) {
        if (busqueda.isEmpty()) {
            cargarPacientes();
        } else {
            List<Paciente> pacientes = db.buscarPacientes(busqueda);
            adapter = new PacienteAdapter(
                    pacientes,
                    this::mostrarDialogoEditar,
                    this::eliminarPaciente,
                    this::abrirHistorial
            );
            rvPacientes.setAdapter(adapter);
        }
    }

    private void abrirHistorial(Paciente paciente) {
        Intent intent = new Intent(PacientesActivity.this, HistorialPacienteActivity.class);
        intent.putExtra("paciente_id", paciente.getId());
        startActivity(intent);
    }

    private void mostrarDialogoAgregar() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_paciente, null);

        EditText etNombre = view.findViewById(R.id.etNombrePaciente);
        EditText etApellidos = view.findViewById(R.id.etApellidosPaciente);
        Spinner spGenero = view.findViewById(R.id.spGeneroPaciente);
        EditText etFechaNac = view.findViewById(R.id.etFechaNacPaciente);

        ArrayAdapter<CharSequence> adapterGenero = ArrayAdapter.createFromResource(
                this, R.array.generos, android.R.layout.simple_spinner_item
        );
        adapterGenero.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spGenero.setAdapter(adapterGenero);

        etFechaNac.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this,
                    (view1, year, month, dayOfMonth) -> {
                        String fecha = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        etFechaNac.setText(fecha);
                    },
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        new AlertDialog.Builder(this)
                .setTitle("Nuevo Paciente")
                .setView(view)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String nombre = etNombre.getText().toString().trim();
                    String apellidos = etApellidos.getText().toString().trim();
                    String genero = spGenero.getSelectedItem().toString();
                    String fechaNac = etFechaNac.getText().toString().trim();

                    if (nombre.isEmpty() || apellidos.isEmpty() || fechaNac.isEmpty()) {
                        Toast.makeText(this, "Completa todos los campos",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Paciente paciente = new Paciente(0, nombre, apellidos, genero, fechaNac);
                    long id = db.insertarPaciente(paciente);

                    if (id > 0) {
                        Toast.makeText(this, "Paciente registrado", Toast.LENGTH_SHORT).show();
                        cargarPacientes();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void mostrarDialogoEditar(Paciente paciente) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_paciente, null);

        EditText etNombre = view.findViewById(R.id.etNombrePaciente);
        EditText etApellidos = view.findViewById(R.id.etApellidosPaciente);
        Spinner spGenero = view.findViewById(R.id.spGeneroPaciente);
        EditText etFechaNac = view.findViewById(R.id.etFechaNacPaciente);

        etNombre.setText(paciente.getNombre());
        etApellidos.setText(paciente.getApellidos());
        etFechaNac.setText(paciente.getFechaNacimiento());

        ArrayAdapter<CharSequence> adapterGenero = ArrayAdapter.createFromResource(
                this, R.array.generos, android.R.layout.simple_spinner_item
        );
        adapterGenero.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spGenero.setAdapter(adapterGenero);

        if (paciente.getGenero() != null) {
            int position = adapterGenero.getPosition(paciente.getGenero());
            spGenero.setSelection(position);
        }

        etFechaNac.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this,
                    (view1, year, month, dayOfMonth) -> {
                        String fecha = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        etFechaNac.setText(fecha);
                    },
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        new AlertDialog.Builder(this)
                .setTitle("Editar Paciente")
                .setView(view)
                .setPositiveButton("Actualizar", (dialog, which) -> {
                    paciente.setNombre(etNombre.getText().toString().trim());
                    paciente.setApellidos(etApellidos.getText().toString().trim());
                    paciente.setGenero(spGenero.getSelectedItem().toString());
                    paciente.setFechaNacimiento(etFechaNac.getText().toString().trim());

                    if (db.actualizarPaciente(paciente)) {
                        Toast.makeText(this, "Paciente actualizado",
                                Toast.LENGTH_SHORT).show();
                        cargarPacientes();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void eliminarPaciente(Paciente paciente) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar Paciente")
                .setMessage("¿Estás seguro de eliminar a " +
                        paciente.getNombreCompleto() + "?")
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    if (db.eliminarPaciente(paciente.getId())) {
                        Toast.makeText(this, "Paciente eliminado",
                                Toast.LENGTH_SHORT).show();
                        cargarPacientes();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}