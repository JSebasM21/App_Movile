package com.example.agenda.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agenda.R;
import com.example.agenda.models.Paciente;

import java.util.List;

public class PacienteAdapter extends RecyclerView.Adapter<PacienteAdapter.PacienteViewHolder> {

    private List<Paciente> pacientes;
    private OnPacienteClickListener clickListener;
    private OnPacienteDeleteListener deleteListener;
    private OnPacienteHistorialListener historialListener;

    public interface OnPacienteClickListener {
        void onPacienteClick(Paciente paciente);
    }

    public interface OnPacienteDeleteListener {
        void onPacienteDelete(Paciente paciente);
    }

    public interface OnPacienteHistorialListener {
        void onPacienteHistorial(Paciente paciente);
    }

    public PacienteAdapter(List<Paciente> pacientes,
                           OnPacienteClickListener clickListener,
                           OnPacienteDeleteListener deleteListener,
                           OnPacienteHistorialListener historialListener) {
        this.pacientes = pacientes;
        this.clickListener = clickListener;
        this.deleteListener = deleteListener;
        this.historialListener = historialListener;
    }

    @NonNull
    @Override
    public PacienteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_paciente, parent, false);
        return new PacienteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PacienteViewHolder holder, int position) {
        Paciente paciente = pacientes.get(position);

        holder.tvNombre.setText(paciente.getNombreCompleto());
        holder.tvEdad.setText(paciente.calcularEdad() + " años");
        holder.tvGenero.setText(paciente.getGenero());

        holder.btnEditar.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onPacienteClick(paciente);
            }
        });

        holder.btnEliminar.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onPacienteDelete(paciente);
            }
        });

        // NUEVO: Botón de historial
        holder.btnHistorial.setOnClickListener(v -> {
            if (historialListener != null) {
                historialListener.onPacienteHistorial(paciente);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pacientes.size();
    }

    static class PacienteViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvEdad, tvGenero;
        Button btnEditar, btnEliminar, btnHistorial;

        public PacienteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombrePacienteItem);
            tvEdad = itemView.findViewById(R.id.tvEdadPacienteItem);
            tvGenero = itemView.findViewById(R.id.tvGeneroPacienteItem);
            btnEditar = itemView.findViewById(R.id.btnEditarPaciente);
            btnEliminar = itemView.findViewById(R.id.btnEliminarPaciente);
            btnHistorial = itemView.findViewById(R.id.btnHistorialPaciente);
        }
    }
}