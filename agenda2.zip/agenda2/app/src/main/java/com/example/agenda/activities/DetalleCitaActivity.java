package com.example.agenda.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.agenda.R;
import com.example.agenda.database.DatabaseHelper;
import com.example.agenda.models.Cita;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DetalleCitaActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private Cita cita;

    private TextView tvPaciente, tvFechaHora, tvDuracion, tvProcedimiento;
    private TextView tvEstado, tvMonto, tvDescripcion;
    private Button btnAsistio, btnCancelo, btnNoAsistio, btnCerrarCita, btnEditarCita;
    private LinearLayout layoutCerrarCita;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_cita);

        // Configurar toolbar con botón de retroceso
        Toolbar toolbar = findViewById(R.id.toolbarDetalleCita);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Detalle de Cita");
        }

        db = new DatabaseHelper(this);

        // Inicializar vistas
        inicializarVistas();

        int citaId = getIntent().getIntExtra("cita_id", -1);

        if (citaId == -1) {
            Toast.makeText(this, "Error al cargar cita", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        cargarCita(citaId);

        // Configurar listeners
        btnAsistio.setOnClickListener(v -> cambiarEstado("asistio"));
        btnCancelo.setOnClickListener(v -> cambiarEstado("cancelo"));
        btnNoAsistio.setOnClickListener(v -> cambiarEstado("no_asistio"));
        btnCerrarCita.setOnClickListener(v -> mostrarDialogoCerrarCita());
        btnEditarCita.setOnClickListener(v -> editarCita());
    }

    private void inicializarVistas() {
        tvPaciente = findViewById(R.id.tvPacienteDetalle);
        tvFechaHora = findViewById(R.id.tvFechaHoraDetalle);
        tvDuracion = findViewById(R.id.tvDuracionDetalle);
        tvProcedimiento = findViewById(R.id.tvProcedimientoDetalle);
        tvEstado = findViewById(R.id.tvEstadoDetalle);
        tvMonto = findViewById(R.id.tvMontoDetalle);
        tvDescripcion = findViewById(R.id.tvDescripcionDetalle);

        btnAsistio = findViewById(R.id.btnAsistio);
        btnCancelo = findViewById(R.id.btnCancelo);
        btnNoAsistio = findViewById(R.id.btnNoAsistio);
        btnCerrarCita = findViewById(R.id.btnCerrarCita);
        btnEditarCita = findViewById(R.id.btnEditarCita);
        layoutCerrarCita = findViewById(R.id.layoutCerrarCita);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        int citaId = getIntent().getIntExtra("cita_id", -1);
        if (citaId != -1) {
            cargarCita(citaId);
        }
    }

    private void cargarCita(int id) {
        cita = db.obtenerCitaPorId(id);

        if (cita == null) {
            Toast.makeText(this, "Cita no encontrada", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvPaciente.setText("👤 Paciente: " + cita.getPacienteNombre());
        tvFechaHora.setText("📅 Fecha: " + cita.getFecha() + " | ⏰ Hora: " +
                cita.getHoraInicio() + " - " + cita.getHoraFin());
        tvDuracion.setText("⏱️ Duración: " + cita.getDuracionMinutos() + " minutos");
        tvProcedimiento.setText("🦷 Procedimiento: " + cita.getTipoProcedimiento());
        tvEstado.setText("📊 Estado: " + obtenerEstadoTexto(cita.getEstado()));

        // Mostrar botón de editar solo si la cita está pendiente
        if (cita.getEstado().equals("pendiente")) {
            btnEditarCita.setVisibility(View.VISIBLE);
        } else {
            btnEditarCita.setVisibility(View.GONE);
        }

        // Mostrar información de cita cerrada
        if (cita.estaCerrada()) {
            tvMonto.setText(String.format(Locale.getDefault(),
                    "💰 Monto Cobrado: $%.2f", cita.getMontoCobrado()));
            tvDescripcion.setText("📝 Tratamiento Realizado:\n" + cita.getDescripcionTratamiento());
            tvMonto.setVisibility(View.VISIBLE);
            tvDescripcion.setVisibility(View.VISIBLE);
            layoutCerrarCita.setVisibility(View.GONE);
        } else {
            tvMonto.setVisibility(View.GONE);
            tvDescripcion.setVisibility(View.GONE);

            // Mostrar opciones solo si la cita ya pasó
            if (citaPasada()) {
                layoutCerrarCita.setVisibility(View.VISIBLE);
            } else {
                layoutCerrarCita.setVisibility(View.GONE);
            }
        }
    }

    private void editarCita() {
        if (cita == null) {
            Toast.makeText(this, "Error: cita no encontrada", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(DetalleCitaActivity.this, NuevaCitaActivity.class);
        intent.putExtra("cita_id", cita.getId());
        startActivity(intent);
    }

    private boolean citaPasada() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm",
                    Locale.getDefault());
            Calendar ahora = Calendar.getInstance();
            Calendar citaCal = Calendar.getInstance();
            citaCal.setTime(sdf.parse(cita.getFecha() + " " + cita.getHoraInicio()));

            return ahora.after(citaCal);
        } catch (Exception e) {
            return false;
        }
    }

    private String obtenerEstadoTexto(String estado) {
        switch (estado) {
            case "asistio": return "✅ Asistió";
            case "cancelo": return "⚠️ Canceló";
            case "no_asistio": return "❌ No asistió";
            default: return "⏳ Pendiente";
        }
    }

    private void cambiarEstado(String nuevoEstado) {
        cita.setEstado(nuevoEstado);

        if (db.actualizarCita(cita)) {
            Toast.makeText(this, "Estado actualizado", Toast.LENGTH_SHORT).show();
            cargarCita(cita.getId());
        } else {
            Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarDialogoCerrarCita() {
        if (!cita.getEstado().equals("asistio")) {
            Toast.makeText(this, "Marca primero que el paciente asistió",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        View view = getLayoutInflater().inflate(R.layout.dialog_cerrar_cita, null);

        EditText etMonto = view.findViewById(R.id.etMontoCobrado);
        EditText etDescripcion = view.findViewById(R.id.etDescripcionTratamiento);

        new AlertDialog.Builder(this)
                .setTitle("💰 Cerrar Cita")
                .setView(view)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String montoStr = etMonto.getText().toString().trim();
                    String descripcion = etDescripcion.getText().toString().trim();

                    if (montoStr.isEmpty() || descripcion.isEmpty()) {
                        Toast.makeText(this, "Completa todos los campos",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double monto = Double.parseDouble(montoStr);
                        cita.setMontoCobrado(monto);
                        cita.setDescripcionTratamiento(descripcion);

                        if (db.actualizarCita(cita)) {
                            Toast.makeText(this, "✅ Cita cerrada exitosamente",
                                    Toast.LENGTH_SHORT).show();
                            cargarCita(cita.getId());
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Monto inválido", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}