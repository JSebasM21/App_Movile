package com.example.agenda.models;

import java.util.Calendar;

public class Paciente {
    private int id;
    private String nombre;
    private String apellidos;
    private String genero;
    private String fechaNacimiento; // Formato: yyyy-MM-dd

    // Constructor vacío
    public Paciente() {}

    // Constructor completo
    public Paciente(int id, String nombre, String apellidos, String genero,
                    String fechaNacimiento) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.genero = genero;
        this.fechaNacimiento = fechaNacimiento;
    }

    // Método para calcular edad automáticamente
    public int calcularEdad() {
        if (fechaNacimiento == null || fechaNacimiento.isEmpty()) {
            return 0;
        }

        try {
            String[] partes = fechaNacimiento.split("-");
            int anioNacimiento = Integer.parseInt(partes[0]);
            int mesNacimiento = Integer.parseInt(partes[1]);
            int diaNacimiento = Integer.parseInt(partes[2]);

            Calendar hoy = Calendar.getInstance();
            int anioActual = hoy.get(Calendar.YEAR);
            int mesActual = hoy.get(Calendar.MONTH) + 1;
            int diaActual = hoy.get(Calendar.DAY_OF_MONTH);

            int edad = anioActual - anioNacimiento;

            if (mesActual < mesNacimiento ||
                    (mesActual == mesNacimiento && diaActual < diaNacimiento)) {
                edad--;
            }

            return edad;
        } catch (Exception e) {
            return 0;
        }
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    public String getNombreCompleto() {
        return nombre + " " + apellidos;
    }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public String getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
}