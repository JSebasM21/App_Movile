package com.example.agenda.activities;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.agenda.R;
import com.example.agenda.database.DatabaseHelper;
import com.example.agenda.models.Odontologo;

public class ConfigPerfilActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText etNombre, etEdad, etHoraInicio, etHoraFin;
    private ImageView ivFotoPerfil;
    private Button btnSeleccionarFoto, btnGuardar;
    private String fotoUri = "";

    private ActivityResultLauncher<Intent> seleccionarFotoLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config_perfil);

        // Configurar toolbar con botón de retroceso
        Toolbar toolbar = findViewById(R.id.toolbarConfigPerfil);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Configurar Perfil");
        }

        db = new DatabaseHelper(this);

        // Inicializar vistas
        etNombre = findViewById(R.id.etNombre);
        etEdad = findViewById(R.id.etEdad);
        etHoraInicio = findViewById(R.id.etHoraInicio);
        etHoraFin = findViewById(R.id.etHoraFin);
        ivFotoPerfil = findViewById(R.id.ivFotoPerfil);
        btnSeleccionarFoto = findViewById(R.id.btnSeleccionarFoto);
        btnGuardar = findViewById(R.id.btnGuardar);

        // Configurar selector de foto
        seleccionarFotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        if (uri != null) {
                            fotoUri = uri.toString();
                            ivFotoPerfil.setImageURI(uri);

                            // Dar permisos permanentes a la URI
                            try {
                                getContentResolver().takePersistableUriPermission(
                                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                                );
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );

        btnSeleccionarFoto.setOnClickListener(v -> seleccionarFoto());

        // Configurar time pickers
        etHoraInicio.setOnClickListener(v -> mostrarTimePicker(etHoraInicio));
        etHoraFin.setOnClickListener(v -> mostrarTimePicker(etHoraFin));

        btnGuardar.setOnClickListener(v -> guardarPerfil());

        cargarDatosExistentes();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void seleccionarFoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        seleccionarFotoLauncher.launch(intent);
    }

    private void mostrarTimePicker(EditText editText) {
        int hora = 8;
        int minuto = 0;

        String texto = editText.getText().toString();
        if (!texto.isEmpty()) {
            String[] partes = texto.split(":");
            try {
                hora = Integer.parseInt(partes[0]);
                minuto = Integer.parseInt(partes[1]);
            } catch (Exception ignored) {}
        }

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    String tiempo = String.format("%02d:%02d", hourOfDay, minute);
                    editText.setText(tiempo);
                },
                hora, minuto, true
        );
        timePickerDialog.show();
    }

    private void cargarDatosExistentes() {
        Odontologo odontologo = db.obtenerOdontologo();
        if (odontologo != null) {
            etNombre.setText(odontologo.getNombreCompleto());
            etEdad.setText(String.valueOf(odontologo.getEdad()));
            etHoraInicio.setText(odontologo.getHoraInicio());
            etHoraFin.setText(odontologo.getHoraFin());
            fotoUri = odontologo.getFotoUri();

            if (fotoUri != null && !fotoUri.isEmpty()) {
                ivFotoPerfil.setImageURI(Uri.parse(fotoUri));
            }
        }
    }

    private void guardarPerfil() {
        String nombre = etNombre.getText().toString().trim();
        String edadStr = etEdad.getText().toString().trim();
        String horaInicio = etHoraInicio.getText().toString().trim();
        String horaFin = etHoraFin.getText().toString().trim();

        if (nombre.isEmpty() || edadStr.isEmpty() ||
                horaInicio.isEmpty() || horaFin.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int edad = Integer.parseInt(edadStr);

        Odontologo odontologo = db.obtenerOdontologo();

        if (odontologo == null) {
            // Insertar nuevo
            odontologo = new Odontologo(0, nombre, edad, fotoUri, horaInicio, horaFin);
            long id = db.insertarOdontologo(odontologo);
            if (id > 0) {
                Toast.makeText(this, "Perfil creado", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else {
            // Actualizar existente
            odontologo.setNombreCompleto(nombre);
            odontologo.setEdad(edad);
            odontologo.setFotoUri(fotoUri);
            odontologo.setHoraInicio(horaInicio);
            odontologo.setHoraFin(horaFin);

            if (db.actualizarOdontologo(odontologo)) {
                Toast.makeText(this, "Perfil actualizado", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
}