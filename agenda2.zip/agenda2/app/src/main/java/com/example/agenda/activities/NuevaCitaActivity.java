package com.example.agenda.activities;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.agenda.R;
import com.example.agenda.database.DatabaseHelper;
import com.example.agenda.models.Cita;
import com.example.agenda.models.Paciente;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NuevaCitaActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private AutoCompleteTextView actvBuscarPaciente;
    private Spinner spDuracion;
    private EditText etFecha, etHoraInicio, etTipoProcedimiento;
    private Button btnGuardar;
    private List<Paciente> listaPacientes;
    private Paciente pacienteSeleccionado;
    private String fechaInicial;
    private int citaIdEditar = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_cita);

        // Configurar toolbar
        Toolbar toolbar = findViewById(R.id.toolbarNuevaCita);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        db = new DatabaseHelper(this);

        // Inicializar vistas
        actvBuscarPaciente = findViewById(R.id.actvBuscarPaciente);
        spDuracion = findViewById(R.id.spDuracion);
        etFecha = findViewById(R.id.etFechaCita);
        etHoraInicio = findViewById(R.id.etHoraInicioCita);
        etTipoProcedimiento = findViewById(R.id.etTipoProcedimiento);
        btnGuardar = findViewById(R.id.btnGuardarCita);

        // Verificar si es modo edición
        citaIdEditar = getIntent().getIntExtra("cita_id", -1);

        if (citaIdEditar != -1) {
            getSupportActionBar().setTitle("Editar Cita");
            btnGuardar.setText("✅ Actualizar Cita");
        } else {
            getSupportActionBar().setTitle("Nueva Cita");
            btnGuardar.setText("✅ Agendar Cita");
            fechaInicial = getIntent().getStringExtra("fecha");
            if (fechaInicial != null) {
                etFecha.setText(fechaInicial);
            }
        }

        cargarPacientes();
        configurarBuscadorPacientes();
        configurarSpinnerDuracion();

        // Si es modo edición, cargar datos
        if (citaIdEditar != -1) {
            cargarDatosCita();
        }

        etFecha.setOnClickListener(v -> mostrarDatePicker());
        etHoraInicio.setOnClickListener(v -> mostrarTimePicker());
        btnGuardar.setOnClickListener(v -> guardarCita());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void cargarDatosCita() {
        Cita cita = db.obtenerCitaPorId(citaIdEditar);
        if (cita != null) {
            etFecha.setText(cita.getFecha());
            etHoraInicio.setText(cita.getHoraInicio());
            etTipoProcedimiento.setText(cita.getTipoProcedimiento());

            // Seleccionar duración
            String duracionStr = cita.getDuracionMinutos() + " minutos";
            ArrayAdapter adapter = (ArrayAdapter) spDuracion.getAdapter();
            if (adapter != null) {
                for (int i = 0; i < adapter.getCount(); i++) {
                    if (adapter.getItem(i).toString().equals(duracionStr)) {
                        spDuracion.setSelection(i);
                        break;
                    }
                }
            }

            // Cargar paciente
            pacienteSeleccionado = db.obtenerPacientePorId(cita.getPacienteId());
            if (pacienteSeleccionado != null) {
                actvBuscarPaciente.setText(pacienteSeleccionado.getNombreCompleto());
            }
        }
    }

    private void cargarPacientes() {
        listaPacientes = db.obtenerTodosPacientes();

        if (listaPacientes.isEmpty()) {
            Toast.makeText(this, "⚠️ Registra pacientes primero",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }
    }

    private void configurarBuscadorPacientes() {
        List<String> nombresPacientes = new ArrayList<>();
        for (Paciente p : listaPacientes) {
            nombresPacientes.add(p.getNombreCompleto());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                nombresPacientes
        );

        actvBuscarPaciente.setAdapter(adapter);
        actvBuscarPaciente.setThreshold(1);

        actvBuscarPaciente.setOnItemClickListener((parent, view, position, id) -> {
            String nombreSeleccionado = (String) parent.getItemAtPosition(position);
            for (Paciente p : listaPacientes) {
                if (p.getNombreCompleto().equals(nombreSeleccionado)) {
                    pacienteSeleccionado = p;
                    break;
                }
            }
        });

        actvBuscarPaciente.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean encontrado = false;
                for (Paciente p : listaPacientes) {
                    if (p.getNombreCompleto().equals(s.toString())) {
                        encontrado = true;
                        pacienteSeleccionado = p;
                        break;
                    }
                }
                if (!encontrado) {
                    pacienteSeleccionado = null;
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void configurarSpinnerDuracion() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.duraciones, android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDuracion.setAdapter(adapter);
    }

    private void mostrarDatePicker() {
        Calendar cal = Calendar.getInstance();

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String fecha = String.format(Locale.getDefault(),
                            "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                    etFecha.setText(fecha);
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void mostrarTimePicker() {
        Calendar cal = Calendar.getInstance();

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    String hora = String.format(Locale.getDefault(),
                            "%02d:%02d", hourOfDay, minute);
                    etHoraInicio.setText(hora);
                },
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                true
        );
        timePickerDialog.show();
    }

    private boolean validarDisponibilidadHorario(String fecha, String horaInicio, int duracion) {
        List<Cita> citasDelDia = db.obtenerCitasPorFecha(fecha);

        List<Cita> citasParaValidar = new ArrayList<>();
        for (Cita c : citasDelDia) {
            if (citaIdEditar == -1 || c.getId() != citaIdEditar) {
                citasParaValidar.add(c);
            }
        }

        if (citasParaValidar.isEmpty()) {
            return true;
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());

            Date horaInicioDate = sdf.parse(horaInicio);
            Calendar calNueva = Calendar.getInstance();
            calNueva.setTime(horaInicioDate);
            calNueva.add(Calendar.MINUTE, duracion);
            Date horaFinNueva = calNueva.getTime();

            for (Cita citaExistente : citasParaValidar) {
                Date horaInicioExistente = sdf.parse(citaExistente.getHoraInicio());

                Calendar calExistente = Calendar.getInstance();
                calExistente.setTime(horaInicioExistente);
                calExistente.add(Calendar.MINUTE, citaExistente.getDuracionMinutos());
                Date horaFinExistente = calExistente.getTime();

                if (horaInicioDate.compareTo(horaInicioExistente) >= 0 &&
                        horaInicioDate.compareTo(horaFinExistente) < 0) {
                    mostrarMensajeConflicto(citaExistente);
                    return false;
                }

                if (horaFinNueva.compareTo(horaInicioExistente) > 0 &&
                        horaFinNueva.compareTo(horaFinExistente) <= 0) {
                    mostrarMensajeConflicto(citaExistente);
                    return false;
                }

                if (horaInicioDate.compareTo(horaInicioExistente) <= 0 &&
                        horaFinNueva.compareTo(horaFinExistente) >= 0) {
                    mostrarMensajeConflicto(citaExistente);
                    return false;
                }
            }

            return true;

        } catch (ParseException e) {
            e.printStackTrace();
            return true;
        }
    }

    private void mostrarMensajeConflicto(Cita citaExistente) {
        String mensaje = String.format(
                "⚠️ Conflicto de horario!\n\n" +
                        "Ya existe una cita:\n" +
                        "• Paciente: %s\n" +
                        "• Hora: %s - %s\n" +
                        "• Procedimiento: %s\n\n" +
                        "Elige otro horario.",
                citaExistente.getPacienteNombre(),
                citaExistente.getHoraInicio(),
                citaExistente.getHoraFin(),
                citaExistente.getTipoProcedimiento()
        );

        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
    }

    private void guardarCita() {
        if (pacienteSeleccionado == null) {
            Toast.makeText(this, "⚠️ Selecciona un paciente de la lista",
                    Toast.LENGTH_SHORT).show();
            actvBuscarPaciente.requestFocus();
            return;
        }

        String fecha = etFecha.getText().toString().trim();
        String horaInicio = etHoraInicio.getText().toString().trim();
        String tipoProcedimiento = etTipoProcedimiento.getText().toString().trim();

        if (fecha.isEmpty() || horaInicio.isEmpty() || tipoProcedimiento.isEmpty()) {
            Toast.makeText(this, "⚠️ Completa todos los campos",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        String duracionStr = spDuracion.getSelectedItem().toString();
        int duracion = Integer.parseInt(duracionStr.split(" ")[0]);

        if (!validarDisponibilidadHorario(fecha, horaInicio, duracion)) {
            return;
        }

        if (citaIdEditar != -1) {
            // Modo edición
            Cita cita = db.obtenerCitaPorId(citaIdEditar);
            if (cita != null) {
                cita.setPacienteId(pacienteSeleccionado.getId());
                cita.setPacienteNombre(pacienteSeleccionado.getNombreCompleto());
                cita.setFecha(fecha);
                cita.setHoraInicio(horaInicio);
                cita.setDuracionMinutos(duracion);
                cita.setTipoProcedimiento(tipoProcedimiento);

                if (db.actualizarCita(cita)) {
                    Toast.makeText(this, "✅ Cita actualizada", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "❌ Error al actualizar", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            // Modo creación
            Cita cita = new Cita();
            cita.setPacienteId(pacienteSeleccionado.getId());
            cita.setPacienteNombre(pacienteSeleccionado.getNombreCompleto());
            cita.setFecha(fecha);
            cita.setHoraInicio(horaInicio);
            cita.setDuracionMinutos(duracion);
            cita.setTipoProcedimiento(tipoProcedimiento);
            cita.setEstado("pendiente");

            long id = db.insertarCita(cita);

            if (id > 0) {
                Toast.makeText(this, "✅ Cita agendada exitosamente", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "❌ Error al agendar", Toast.LENGTH_SHORT).show();
            }
        }
    }
}