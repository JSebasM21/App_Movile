package com.example.agenda.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agenda.R;
import com.example.agenda.models.Cita;

import java.util.List;

public class CitaAdapter extends RecyclerView.Adapter<CitaAdapter.CitaViewHolder> {

    private List<Cita> citas;
    private OnCitaClickListener clickListener;

    public interface OnCitaClickListener {
        void onCitaClick(Cita cita);
    }

    public CitaAdapter(List<Cita> citas, OnCitaClickListener clickListener) {
        this.citas = citas;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public CitaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cita, parent, false);
        return new CitaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CitaViewHolder holder, int position) {
        Cita cita = citas.get(position);

        holder.tvHora.setText(cita.getHoraInicio() + " - " + cita.getHoraFin());
        holder.tvPaciente.setText(cita.getPacienteNombre());
        holder.tvProcedimiento.setText(cita.getTipoProcedimiento());
        holder.tvDuracion.setText(cita.getDuracionMinutos() + " min");

        // Cambiar color según estado
        int colorFondo;
        String estadoTexto;

        switch (cita.getEstado()) {
            case "asistio":
                colorFondo = Color.parseColor("#4CAF50"); // Verde
                estadoTexto = "Completada";
                break;
            case "cancelo":
                colorFondo = Color.parseColor("#FF9800"); // Naranja
                estadoTexto = "Cancelada";
                break;
            case "no_asistio":
                colorFondo = Color.parseColor("#F44336"); // Rojo
                estadoTexto = "No asistió";
                break;
            default:
                colorFondo = Color.parseColor("#2196F3"); // Azul
                estadoTexto = "Pendiente";
                break;
        }

        holder.cardView.setCardBackgroundColor(colorFondo);
        holder.tvEstado.setText(estadoTexto);

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onCitaClick(cita);
            }
        });
    }

    @Override
    public int getItemCount() {
        return citas.size();
    }

    static class CitaViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvHora, tvPaciente, tvProcedimiento, tvDuracion, tvEstado;

        public CitaViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardViewCita);
            tvHora = itemView.findViewById(R.id.tvHoraCitaItem);
            tvPaciente = itemView.findViewById(R.id.tvPacienteCitaItem);
            tvProcedimiento = itemView.findViewById(R.id.tvProcedimientoCitaItem);
            tvDuracion = itemView.findViewById(R.id.tvDuracionCitaItem);
            tvEstado = itemView.findViewById(R.id.tvEstadoCitaItem);
        }
    }
}