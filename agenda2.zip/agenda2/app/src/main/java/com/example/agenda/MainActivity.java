package com.example.agenda;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.agenda.activities.AgendaActivity;
import com.example.agenda.activities.ConfigPerfilActivity;
import com.example.agenda.activities.PacientesActivity;
import com.example.agenda.activities.ReportesActivity;
import com.example.agenda.database.DatabaseHelper;
import com.example.agenda.models.Odontologo;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private TextView tvNombreDoctor, tvHorario;
    private ImageView ivFotoDoctor;
    private Button btnConfigPerfil, btnPacientes, btnAgenda, btnReportes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        // Inicializar vistas
        tvNombreDoctor = findViewById(R.id.tvNombreDoctor);
        tvHorario = findViewById(R.id.tvHorario);
        ivFotoDoctor = findViewById(R.id.ivFotoDoctor);
        btnConfigPerfil = findViewById(R.id.btnConfigPerfil);
        btnPacientes = findViewById(R.id.btnPacientes);
        btnAgenda = findViewById(R.id.btnAgenda);
        btnReportes = findViewById(R.id.btnReportes);

        // Configurar botones
        btnConfigPerfil.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ConfigPerfilActivity.class);
            startActivity(intent);
        });

        btnPacientes.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PacientesActivity.class);
            startActivity(intent);
        });

        btnAgenda.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AgendaActivity.class);
            startActivity(intent);
        });

        btnReportes.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ReportesActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatosDoctor();
    }

    private void cargarDatosDoctor() {
        Odontologo odontologo = db.obtenerOdontologo();

        if (odontologo != null) {
            tvNombreDoctor.setText(odontologo.getNombreCompleto());
            tvHorario.setText("Horario: " + odontologo.getHoraInicio() +
                    " - " + odontologo.getHoraFin());

            if (odontologo.getFotoUri() != null && !odontologo.getFotoUri().isEmpty()) {
                ivFotoDoctor.setImageURI(Uri.parse(odontologo.getFotoUri()));
            }
        } else {
            tvNombreDoctor.setText("Dr. Arango");
            tvHorario.setText("Configura tu perfil");
        }
    }
}