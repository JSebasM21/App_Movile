package com.example.agenda.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agenda.R;
import com.example.agenda.models.Cita;

import java.util.List;
import java.util.Locale;

public class HistorialAdapter extends RecyclerView.Adapter<HistorialAdapter.HistorialViewHolder> {

    private List<Cita> historial;
    private OnCitaClickListener clickListener;

    public interface OnCitaClickListener {
        void onCitaClick(Cita cita);
    }

    public HistorialAdapter(List<Cita> historial, OnCitaClickListener clickListener) {
        this.historial = historial;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public HistorialViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_historial, parent, false);
        return new HistorialViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistorialViewHolder holder, int position) {
        Cita cita = historial.get(position);

        // Siempre mostrar fecha, hora y procedimiento
        holder.tvFechaHistorial.setText("📅 " + cita.getFecha());
        holder.tvHoraHistorial.setText("⏰ " + cita.getHoraInicio() + " - " + cita.getHoraFin());
        holder.tvProcedimientoHistorial.setText("🦷 " + cita.getTipoProcedimiento());

        String estado = cita.getEstado();
        boolean estaCerrada = cita.getMontoCobrado() > 0 &&
                cita.getDescripcionTratamiento() != null &&
                !cita.getDescripcionTratamiento().isEmpty();

        // Determinar tipo y configurar vista
        if ("asistio".equals(estado) && estaCerrada) {
            // ============ CITA TRATADA Y CERRADA ============
            configurarCitaTratada(holder, cita);

        } else if ("pendiente".equals(estado)) {
            // ============ CITA PENDIENTE ============
            configurarCitaPendiente(holder);

        } else if ("asistio".equals(estado) && !estaCerrada) {
            // ============ ASISTIÓ PERO NO CERRADA ============
            configurarCitaSinCerrar(holder);

        } else if ("cancelo".equals(estado)) {
            // ============ CITA CANCELADA ============
            configurarCitaCancelada(holder);

        } else if ("no_asistio".equals(estado)) {
            // ============ NO ASISTIÓ ============
            configurarCitaNoAsistio(holder);
        }

        // Click listener
        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onCitaClick(cita);
            }
        });
    }

    private void configurarCitaTratada(HistorialViewHolder holder, Cita cita) {
        // Etiqueta
        holder.tvTipoCita.setText("✅ CITA TRATADA");
        holder.tvTipoCita.setTextColor(Color.parseColor("#4CAF50"));
        holder.tvTipoCita.setVisibility(View.VISIBLE);

        // Descripción del tratamiento
        holder.tvDescripcionHistorial.setText("📝 Tratamiento realizado:\n" +
                cita.getDescripcionTratamiento());
        holder.tvDescripcionHistorial.setVisibility(View.VISIBLE);

        // Monto
        holder.tvMontoHistorial.setText(String.format(Locale.getDefault(),
                "💰 Monto cobrado: $%.2f", cita.getMontoCobrado()));
        holder.tvMontoHistorial.setVisibility(View.VISIBLE);

        // Estado
        holder.tvEstadoHistorial.setText("✓ Completada");
        holder.tvEstadoHistorial.setTextColor(Color.parseColor("#4CAF50"));

        // Color de fondo
        holder.cardView.setCardBackgroundColor(Color.parseColor("#E8F5E9"));
    }

    private void configurarCitaPendiente(HistorialViewHolder holder) {
        // Etiqueta
        holder.tvTipoCita.setText("⏳ CITA PENDIENTE - Toca para editar");
        holder.tvTipoCita.setTextColor(Color.parseColor("#2196F3"));
        holder.tvTipoCita.setVisibility(View.VISIBLE);

        // Ocultar tratamiento y monto
        holder.tvDescripcionHistorial.setVisibility(View.GONE);
        holder.tvMontoHistorial.setVisibility(View.GONE);

        // Estado
        holder.tvEstadoHistorial.setText("○ Pendiente");
        holder.tvEstadoHistorial.setTextColor(Color.parseColor("#2196F3"));

        // Color de fondo
        holder.cardView.setCardBackgroundColor(Color.parseColor("#E3F2FD"));
    }

    private void configurarCitaSinCerrar(HistorialViewHolder holder) {
        // Etiqueta
        holder.tvTipoCita.setText("⚠ ASISTIÓ - Falta cerrar la cita");
        holder.tvTipoCita.setTextColor(Color.parseColor("#FF9800"));
        holder.tvTipoCita.setVisibility(View.VISIBLE);

        // Ocultar tratamiento y monto
        holder.tvDescripcionHistorial.setVisibility(View.GONE);
        holder.tvMontoHistorial.setVisibility(View.GONE);

        // Estado
        holder.tvEstadoHistorial.setText("⚠ Sin cerrar");
        holder.tvEstadoHistorial.setTextColor(Color.parseColor("#FF9800"));

        // Color de fondo
        holder.cardView.setCardBackgroundColor(Color.parseColor("#FFF9C4"));
    }

    private void configurarCitaCancelada(HistorialViewHolder holder) {
        // Ocultar etiqueta
        holder.tvTipoCita.setVisibility(View.GONE);
        holder.tvDescripcionHistorial.setVisibility(View.GONE);
        holder.tvMontoHistorial.setVisibility(View.GONE);

        // Estado
        holder.tvEstadoHistorial.setText("✗ Cancelada");
        holder.tvEstadoHistorial.setTextColor(Color.parseColor("#FF9800"));

        // Color de fondo
        holder.cardView.setCardBackgroundColor(Color.parseColor("#FFF3E0"));
    }

    private void configurarCitaNoAsistio(HistorialViewHolder holder) {
        // Ocultar etiqueta
        holder.tvTipoCita.setVisibility(View.GONE);
        holder.tvDescripcionHistorial.setVisibility(View.GONE);
        holder.tvMontoHistorial.setVisibility(View.GONE);

        // Estado
        holder.tvEstadoHistorial.setText("✗ No asistió");
        holder.tvEstadoHistorial.setTextColor(Color.parseColor("#F44336"));

        // Color de fondo
        holder.cardView.setCardBackgroundColor(Color.parseColor("#FFEBEE"));
    }

    @Override
    public int getItemCount() {
        // CRÍTICO: Retornar el tamaño completo de la lista
        return historial != null ? historial.size() : 0;
    }

    static class HistorialViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvFechaHistorial, tvProcedimientoHistorial, tvDescripcionHistorial;
        TextView tvMontoHistorial, tvEstadoHistorial, tvHoraHistorial, tvTipoCita;

        public HistorialViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardViewHistorial);
            tvFechaHistorial = itemView.findViewById(R.id.tvFechaHistorial);
            tvProcedimientoHistorial = itemView.findViewById(R.id.tvProcedimientoHistorial);
            tvHoraHistorial = itemView.findViewById(R.id.tvHoraHistorial);
            tvDescripcionHistorial = itemView.findViewById(R.id.tvDescripcionHistorial);
            tvMontoHistorial = itemView.findViewById(R.id.tvMontoHistorial);
            tvEstadoHistorial = itemView.findViewById(R.id.tvEstadoHistorial);
            tvTipoCita = itemView.findViewById(R.id.tvTipoCita);
        }
    }
}